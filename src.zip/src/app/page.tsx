import Link from "next/link"

export default function Home() {
  return (
    <section className="text-center py-24">
      <h1 className="text-5xl font-bold mb-6">
        Welcome to Ecom 
      </h1>
      <p className="text-gray-600 mb-8">
        Premium products. Best prices. Fast delivery.
      </p>

      <Link
        href="/products"
        className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition"
      >
        Shop Now
      </Link>
    </section>
  )
}