"use client"
import { useCart } from "../context/CartContext"

export default function AddToCartButton({ product }: any) {
  const { addToCart } = useCart()

  return (
    <button
      onClick={() => addToCart(product)}
      className="w-full mt-4 bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition"
    >
      Add to Cart
    </button>
  )
}