"use client"

import Link from "next/link"
import { useCart } from "../context/CartContext"

export default function Navbar() {
  const { totalItems } = useCart()

  return (
    <nav className="bg-white border-b shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">

        {/* Logo */}
        <Link
          href="/"
          className="text-2xl font-extrabold text-gray-900 tracking-tight"
        >
          Ecom
        </Link>

        {/* Navigation Links */}
        <div className="flex items-center gap-8 text-gray-800 font-medium">

          <Link
            href="/products"
            className="hover:text-blue-600 transition-colors duration-200"
          >
            Products
          </Link>

          <Link
            href="/about"
            className="hover:text-blue-600 transition-colors duration-200"
          >
            About
          </Link>

          <Link
            href="/contact"
            className="hover:text-blue-600 transition-colors duration-200"
          >
            Contact
          </Link>

          {/* Cart */}
          <Link
            href="/cart"
            className="relative font-semibold hover:text-blue-600 transition"
          >
            Cart

            {totalItems > 0 && (
              <span className="absolute -top-2 -right-4 bg-red-500 text-white text-xs font-semibold px-2 py-0.5 rounded-full">
                {totalItems}
              </span>
            )}
          </Link>

        </div>
      </div>
    </nav>
  )
}